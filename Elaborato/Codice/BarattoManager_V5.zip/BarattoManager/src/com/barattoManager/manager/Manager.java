package com.barattoManager.manager;

/**
 * Marker interface for any manager
 */
public interface Manager {}

package com.barattoManager.ui.customComponents.tree.article;

import com.barattoManager.model.article.Article;
import com.barattoManager.utils.History;
import com.barattoManager.utils.TreeUtils;

import javax.swing.tree.DefaultMutableTreeNode;

/**
 * Class that represent the article tree in the dashboard of the viewer
 */
public final class ArticleTreeDashboard extends ArticleTree {

	private DefaultMutableTreeNode rootNode;

	/**
	 * {@link ArticleTreeDashboard} constructor
	 * @param usernameFilter Username filter
	 * @param stateFilter State filter
	 */
	public ArticleTreeDashboard(String usernameFilter, Article.State stateFilter) {
		super(usernameFilter, stateFilter);
	}

	@Override
	protected void createNode(Article article, DefaultMutableTreeNode fatherNode) {
		var articleNode = new DefaultMutableTreeNode(article.getArticleName());

		articleNode.add(new DefaultMutableTreeNode("Proprietario: %s".formatted(article.getUserNameOwner())));
		articleNode.add(new DefaultMutableTreeNode("UUID: %s".formatted(article.getUuid())));

		articleNode.add(TreeUtils.generateFields(article));

		var historyNode = new DefaultMutableTreeNode("Log");
		for (History history : article.getHistory()) {
			historyNode.add(
					new DefaultMutableTreeNode("%s ~ %s - %s - %s".formatted(
							history.name().isPresent() ? "\u2705" : "\u274C",
							history.dateTime(),
							history.name().isPresent() ? history.name().get() : history.error().orElseThrow(NullPointerException::new),
							history.description().orElseThrow(NullPointerException::new)
					)));
		}
		articleNode.add(historyNode);

		fatherNode.add(articleNode);
	}

	@Override
	protected DefaultMutableTreeNode getRootNode() {
		if (rootNode == null)
			rootNode = new DefaultMutableTreeNode("Categorie");

		return rootNode;
	}
}
